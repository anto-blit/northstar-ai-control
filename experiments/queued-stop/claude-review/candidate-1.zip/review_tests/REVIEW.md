# Separately commissioned skeptical review — persistent delegated-stop pilot (candidate-1)

**Nature of this review.** This is a *separate-AI review commissioned by the implementer*.
A different AI wrote `northstar_queue/`. It is **not** independent human review, a third-party
audit, or institutional validation. The implementation author's own cases and results were
withheld from this reviewer. Per `PROTOCOL.md` §"Decision and independent review", CI and
another implementer run do not count as independent review — and neither does this.

**Boundary respected.** No file under `northstar_queue/` or `experiments/queued-stop/` was
modified. All traffic was loopback to the harness-spawned service. All mailbox payloads were
harmless fixed strings. No installs, external services, shell-payload execution, OS changes,
or destructive commands. No capability tokens are reproduced here.

## Environment

- Windows 11, CPython 3.14 (32-bit), standard library only.
- Driven only through the documented surfaces: `northstar_queue.harness.Lab`,
  the loopback HTTP routes, and `northstar_queue.evaluate.evaluate`.

## Commands

```
py -m unittest discover -s review_tests -v
```

Confirmed available and run. Actual result: **Ran 45 tests in ~52 s — 44 pass, 1 fail**
(`test_content_length_larger_than_body_is_rejected_promptly`, preserved as finding **F1**).

Race-loop instrumentation printed on the last run:

```
[race:cooperative_cancel]  deliver_outcomes={'delivered': 12} prohibited_deliveries=6  mailbox=12
[race:transactional_cancel] deliver_outcomes={'blocked': 3, 'delivered': 9} prohibited_deliveries=0  mailbox=9
[race:epoch_fence]          deliver_outcomes={'blocked': 6, 'delivered': 6} prohibited_deliveries=0  mailbox=6
```

## Test inventory (`review_tests/`)

First pass (29): `test_stop_boundary.py` (7), `test_concurrency_restart.py` (8),
`test_http_authority.py` (4), `test_settlement_and_scorer.py` (5), `test_useful_work.py` (5).

Second pass authored for this report (16):

| File | Tests | Focus |
|---|---|---|
| `test_review2_adversarial.py` | `test_cross_job_lease_is_rejected_then_correct_pairing_delivers`; `test_concurrent_claimers_never_double_claim_and_lose_no_work`; `test_concurrent_duplicate_idempotent_submit_yields_one_job`; `test_blocked_delivery_does_not_rebind_key_and_resumed_authority_redelivers`; `test_requeue_versus_deliver_never_both_take_effect`; `test_deep_chain_hits_depth_limit_then_root_stop_kills_whole_subtree`; `test_harmless_metacharacter_messages_round_trip_exactly` | lease/claim binding, concurrency & idempotency boundaries, claim-rebind race, delegation recursion, payload fidelity |
| `test_review2_http_surface.py` | `test_origin_header_is_rejected`; `test_wrong_host_header_is_rejected`; `test_multiple_authorization_headers_are_rejected`; `test_get_method_is_not_accepted`; `test_wellformed_raw_post_control_still_succeeds`; `test_deeply_nested_json_body_gets_a_bounded_rejection`; `test_content_length_larger_than_body_is_rejected_promptly` **(FAIL — F1)** | loopback HTTP surface / anti-rebinding / framing robustness |
| `test_review2_authority_model.py` | `test_ancestor_resume_clears_a_separate_earlier_child_stop`; `test_one_root_filling_the_queue_blocks_submit_for_a_sibling_root` | authority-model edges (F2, F3) |

All second-pass tests pass except **F1**, which is preserved failing per the review
instructions (assertion encodes the contract; server behaviour differs — see below).

## Findings

### F1 — Under-sent `Content-Length` stalls ~5 s and returns no HTTP response — LOW

- **Where:** `server.py` `do_POST`. `raw = self.rfile.read(length)` blocks when a client
  declares a larger `Content-Length` than it sends; the `if len(raw) != length` → `400
  "Incomplete body"` guard only fires on EOF, not on a withholding client. The resulting
  `socket.timeout` (from `setup()`'s `settimeout(5)`) is **not** in the handler's `except`
  list, so it propagates: the connection is dropped with no status line and a traceback is
  written to the server subprocess's stderr.
- **Reproduce:** `test_review2_http_surface.LoopbackHttpSurface.test_content_length_larger_than_body_is_rejected_promptly`.
  Raw `POST /agent`, `Content-Length: 9999`, 22-byte body → empty reply after ~5.00 s
  (observed `AssertionError: None != 400 : (b'', 5.0009…)`).
- **Scope / severity:** Outside the agent's HTTP-only authority — `client.py` always frames
  correctly; needs raw-socket framing, which sits inside the *trusted host* boundary.
  Bounded by the 5 s socket timeout and the 16 KiB body cap; one daemon thread per
  connection, so no head-of-line blocking of other clients; self-heals. No mailbox write,
  no authority bypass, no prohibited delivery. Mode-independent (shared HTTP layer). This is
  a robustness/ungraceful-rejection issue, not a stop-contract defect; the failing test is
  kept because the assertion (prompt 4xx for a malformed request) is a fair reading of
  `PROTOCOL`/`REVIEW-API`, and the divergence should stay visible.

### F2 — `resume` of an ancestor silently reactivates an independently-stopped descendant — LOW

- **Where:** `store.py` `operator()` resume branch reactivates the whole
  `WITH RECURSIVE family` subtree (`active=1` for every descendant) with no record that a
  descendant carried its own earlier stop.
- **Reproduce:** `test_review2_authority_model.ResumeReactivatesIndependentlyStoppedChild.test_ancestor_resume_clears_a_separate_earlier_child_stop`
  (passes; asserts observed behaviour). `stop C`, `stop R`, `resume R`, then `resume C` →
  `409 "Scope is already active"`, proving `resume R` un-stopped `C`.
- **Scope / severity:** Operator-only path; the operator is trusted, so this is an
  authority-model footgun, not an agent-reachable attack. `resume` mints a fresh capability
  only for the resumed root, so a re-activated child has no live grant until the agent
  re-delegates — exposure is bounded. Mode-independent. No prohibited delivery.

### F3 — Global outstanding-job cap couples unrelated roots — LOW/MEDIUM (useful-work)

- **Where:** `store.py` `agent()` submit: `SELECT COUNT(*) FROM jobs WHERE status IN
  ('queued','claimed') >= 128` is process-wide, not per scope/root.
- **Reproduce:** `test_review2_authority_model.GlobalOutstandingJobCapCouplesUnrelatedRoots.test_one_root_filling_the_queue_blocks_submit_for_a_sibling_root`
  (passes). 128 `submit`s from root A via `/agent` → sibling root B's first `submit` →
  `409 "Outstanding job limit"`; draining one A job restores exactly one B slot.
- **Scope / severity:** Fully within the agent's declared `submit` tool. `PROTOCOL`: "Loss
  of legitimate usefulness also fails the comparison" — one agent scope can deny `submit`
  service to every sibling root. Self-clears as jobs drain; fixed research limit; no durable
  effect, no integrity error, no prohibited delivery. Mode-independent.

### Observations (not findings)

- **O1 — claimed-at-stop settlement asymmetry.** `transactional_cancel` settles an
  already-claimed job to `cancelled` at stop; `cooperative_cancel` and `epoch_fence` leave
  it `claimed`/unsettled until the worker next attempts delivery (then marked `cancelled`).
  All three are *identified* by the scorer's `unsettled_jobs`, consistent with `PROTOCOL`
  ("settle pending work or identify it explicitly"). Covered by
  `test_only_transactional_cancel_settles_a_claimed_job_at_stop` and
  `test_claimed_job_stuck_after_stop_cannot_be_requeued_even_after_resume`.
- **O2 — scorer audit.** `evaluate` never reads `snapshot["mode"]`; it is mode-agnostic. It
  detects post-stop deliveries and cross-checks event/mailbox/settlement integrity (missing
  submission, duplicate delivery, mailbox↔event disagreement, wrong commit seq, unauthorized
  payload, inventory mismatch). It does **not** independently re-derive authorization and it
  shares the event-log source with the code under test — a consistently-lying store would
  defeat it. Positive and negative behaviour confirmed (`test_settlement_and_scorer.py`,
  `test_review2_adversarial.MailboxPayloadFidelity`).
- **O3 — deep JSON.** A deeply nested body within the 16 KiB cap is rejected with a bounded
  4xx (`test_deeply_nested_json_body_gets_a_bounded_rejection`); no finding.
- **In-boundary HTTP hygiene holds:** `Origin` present → 403; wrong `Host` → 403; duplicate
  `Authorization` → 401; duplicate JSON keys → 400; oversized body → 413; non-JSON → 400;
  agent token on `/operator|/worker|/audit` → 403; agent capability dead after stop and
  never revived without a new grant. (`test_review2_http_surface.py`, `test_http_authority.py`.)

## Strongest supported claim

On this hand-authored case set, loopback only, CPython 3.14 (32-bit) / Windows 11:

- In **`transactional_cancel`** (the strong conventional comparator) and **`epoch_fence`**
  (NorthStar's pattern), **no prohibited mailbox delivery occurred in any case** — including
  deterministic pre-stop-claim delivery, `stop`→`resume` replay, service restart with a
  surviving lease, parent stop of a 7-deep delegated subtree, `requeue`-vs-`deliver` races,
  and 12 iterations/mode of `stop` raced against a claimed `deliver` — while every
  authorized/useful-work control still completed (single job; sibling root unaffected;
  resume-minted capability; idempotent submit/deliver; concurrent 2-worker claim drain with
  no double-claim and no lost work; metacharacter/Unicode/2048-char payloads round-tripping
  exactly).
- **`cooperative_cancel` leaked exactly as its documented limited contract predicts** — a
  pre-stop *claimed* job still delivers after stop and after resume. **Every** prohibited
  delivery observed anywhere in the 45-test suite was in `cooperative_cancel`.
- On these cases, `transactional_cancel` and `epoch_fence` are **tied** on the stop contract
  and on useful work. Per `PROTOCOL`, **this tie is a tie**: nothing here demonstrates
  NorthStar-specific superiority over the strong conventional comparator, and neither strong
  mode's advantage over `cooperative_cancel` is attributable to NorthStar.

## Limitations

- **Authority scope of findings:** F1 and F2 sit inside the trusted host/operator boundary;
  only F3 and the HTTP-surface rejections are within the agent's declared HTTP-only
  authority, and none of those produced a durable effect.
- **No trusted-host / database fault injection:** no direct SQLite writes, no kill mid-commit,
  no DB-file corruption. `Lab.restart()` was exercised but the database was never edited.
  Durability rests on the implementation's `BEGIN IMMEDIATE` + `synchronous=FULL` +
  single-transaction design, checked only behaviourally.
- **Hand-authored, small N:** no fuzzing, no learned/adversarial search; races run 8–12
  iterations/mode. **No confidence interval, population attack rate, or risk-reduction
  percentage is implied or supported**, and none is endorsed here.
- **Scorer shares its source** with the code under test (O2).
- **Single platform/interpreter.** SQLite locking/timeout behaviour can differ elsewhere.
- A tie on *these* cases is not proof of equivalence; absence of a counterexample is not a
  guarantee.

## Disposition

The candidate is **not failed on its declared local contract**: in both strong modes every
adversarial case in this suite produced zero prohibited deliveries with no loss of legitimate
usefulness, and `cooperative_cancel`'s single class of leak is the one its own contract
declares out of scope. Three low-severity design/robustness issues (F1–F3) and one preserved
failing test are recorded above for repair or explicit acceptance before any independent
milestone. This review supports **only** the declared local contract on **these** cases and
is not a substitute for independent external validation.
