"""Second-pass characterisation of two authority-model edges found by static read.

1. resume of an ancestor silently reactivates a descendant that was stopped
   independently earlier (operator-only path; operator is trusted, so this is a
   design/footgun observation, not an agent attack).
2. the outstanding-job cap counted by submit() is global, so one agent scope can
   deny submit service to unrelated sibling roots (reachable through the agent's
   declared /agent submit tool).

Both are mode-independent (shared store.py code). Neither produces a prohibited
mailbox delivery; they are recorded with reproduction, not as pass/fail security
gates. Assertions here encode the *observed* behaviour so a future change is
noticed.
"""
import unittest

from support import MODES, MSG, evaluate, lab


class ResumeReactivatesIndependentlyStoppedChild(unittest.TestCase):
    def test_ancestor_resume_clears_a_separate_earlier_child_stop(self):
        for mode in MODES:
            with self.subTest(mode=mode), lab(mode) as instance:
                root = instance.operator("create")
                child = instance.agent(root["token"], "delegate")

                # Operator stops the child specifically, for its own reason.
                instance.operator("stop", scope=child["scope"])
                # Later, an unrelated broad stop + resume of the root.
                instance.operator("stop", scope=root["scope"])
                instance.operator("resume", scope=root["scope"])

                # If the child kept its independent stop, resuming it now would
                # succeed (ancestor is active). Observed: it is already active,
                # i.e. the root resume silently un-stopped it.
                again = instance.request(
                    "/operator", {"action": "resume", "scope": child["scope"]})
                self.assertEqual(again["status"], 409, msg=again)
                self.assertEqual(again["body"]["error"], "Scope is already active")

                report = evaluate(instance.snapshot())
                self.assertEqual(report["prohibited_deliveries"], 0)
                self.assertEqual(report["integrity_errors"], [])


class GlobalOutstandingJobCapCouplesUnrelatedRoots(unittest.TestCase):
    CAP = 128

    def test_one_root_filling_the_queue_blocks_submit_for_a_sibling_root(self):
        mode = "epoch_fence"
        with lab(mode) as instance:
            filler = instance.operator("create")
            sibling = instance.operator("create")

            for i in range(self.CAP):
                res = instance.request(
                    "/agent",
                    {"action": "submit", "key": f"f{i}", "message": MSG},
                    token=filler["token"])
                self.assertEqual(res["status"], 200, msg=(i, res))

            # The sibling root is untouched, active, with its own capability, yet
            # cannot submit any work.
            blocked = instance.request(
                "/agent",
                {"action": "submit", "key": "s0", "message": MSG},
                token=sibling["token"])
            self.assertEqual(blocked["status"], 409, msg=blocked)
            self.assertEqual(blocked["body"]["error"], "Outstanding job limit")

            # Draining one filler job frees exactly one slot for the sibling.
            claim = instance.worker("claim")
            self.assertEqual(
                instance.worker("deliver", job=claim["job"], lease=claim["lease"])["status"],
                "delivered")
            recovered = instance.request(
                "/agent",
                {"action": "submit", "key": "s0", "message": MSG},
                token=sibling["token"])
            self.assertEqual(recovered["status"], 200, msg=recovered)

            # Pending work is explicitly identified per PROTOCOL, not left silent.
            report = evaluate(instance.snapshot())
            self.assertEqual(report["prohibited_deliveries"], 0)
            self.assertEqual(report["integrity_errors"], [])
            # 127 filler still queued/claimed + 1 fresh sibling job = CAP.
            self.assertEqual(len(report["unsettled_jobs"]), self.CAP)


if __name__ == "__main__":
    unittest.main()
