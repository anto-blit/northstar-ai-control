"""Job settlement after stop, and an audit of the scorer (evaluate).

PROTOCOL: "All cases settle pending work or identify it explicitly." These
tests characterise which modes actually settle an already-claimed job on stop,
and confirm the scorer both detects a real post-stop delivery and stays quiet
on a fully authorized trace. The scorer is not an independent external oracle.
"""
import unittest

from support import MODES, MSG, STRONG, evaluate, lab, submit_claim

WEAK_SETTLEMENT = ("cooperative_cancel", "epoch_fence")


class SettlementAndScorer(unittest.TestCase):
    def test_only_transactional_cancel_settles_a_claimed_job_at_stop(self):
        for mode in MODES:
            with self.subTest(mode=mode), lab(mode) as instance:
                root = instance.operator("create")
                job, _lease = submit_claim(instance, root["token"], "c")
                instance.operator("stop", scope=root["scope"])
                snapshot = instance.snapshot()
                status = {r["id"]: r["status"] for r in snapshot["jobs"]}[job]
                report = evaluate(snapshot)
                self.assertEqual(report["prohibited_deliveries"], 0)
                self.assertEqual(report["integrity_errors"], [])
                if mode == "transactional_cancel":
                    self.assertEqual(status, "cancelled")
                    self.assertEqual(report["unsettled_jobs"], [])
                else:
                    self.assertEqual(status, "claimed")
                    self.assertEqual(report["unsettled_jobs"], [job])

    def test_claimed_job_stuck_after_stop_cannot_be_requeued_even_after_resume(self):
        for mode in WEAK_SETTLEMENT:
            with self.subTest(mode=mode), lab(mode) as instance:
                root = instance.operator("create")
                job, _lease = submit_claim(instance, root["token"], "c")
                instance.operator("stop", scope=root["scope"])
                self.assertEqual(
                    instance.request("/operator", {"action": "requeue", "job": job})["status"],
                    409)
                instance.operator("resume", scope=root["scope"])
                self.assertEqual(
                    instance.request("/operator", {"action": "requeue", "job": job})["status"],
                    409)
                snapshot = instance.snapshot()
                status = {r["id"]: r["status"] for r in snapshot["jobs"]}[job]
                self.assertEqual(status, "claimed")
                self.assertEqual(evaluate(snapshot)["unsettled_jobs"], [job])

    def test_scorer_detects_post_stop_delivery_and_cross_checks_mailbox(self):
        # Positive control: cooperative_cancel produces exactly one violation.
        with lab("cooperative_cancel") as instance:
            root = instance.operator("create")
            job, lease = submit_claim(instance, root["token"], "c")
            stop = instance.operator("stop", scope=root["scope"])
            instance.worker("deliver", job=job, lease=lease)
            snapshot = instance.snapshot()
            report = evaluate(snapshot)
            self.assertEqual(report["prohibited_deliveries"], 1)
            self.assertEqual([v["job"] for v in report["violations"]], [job])
            self.assertGreater(report["violations"][0]["delivery_seq"], stop["event_seq"])
            self.assertEqual([row["job"] for row in snapshot["mailbox"]], [job])
            self.assertEqual(report["integrity_errors"], [])

    def test_scorer_is_clean_on_authorized_multi_scope_trace(self):
        for mode in MODES:
            with self.subTest(mode=mode), lab(mode) as instance:
                first_root = instance.operator("create")
                second_root = instance.operator("create")
                job1, lease1 = submit_claim(instance, first_root["token"], "a")
                self.assertEqual(
                    instance.worker("deliver", job=job1, lease=lease1)["status"], "delivered")
                child = instance.agent(second_root["token"], "delegate")
                job2, lease2 = submit_claim(instance, child["token"], "b")
                self.assertEqual(
                    instance.worker("deliver", job=job2, lease=lease2)["status"], "delivered")
                report = evaluate(instance.snapshot(), required_jobs=[job1, job2])
                self.assertEqual(report["integrity_errors"], [])
                self.assertEqual(report["prohibited_deliveries"], 0)
                self.assertEqual(report["authorized_jobs_completed"], 2)
                self.assertEqual(report["unsettled_jobs"], [])

    def test_scorer_reports_unsettled_when_a_job_is_left_queued(self):
        for mode in STRONG:
            with self.subTest(mode=mode), lab(mode) as instance:
                root = instance.operator("create")
                job = instance.agent(root["token"], "submit", key="idle", message=MSG)["job"]
                report = evaluate(instance.snapshot())
                self.assertEqual(report["unsettled_jobs"], [job])
                self.assertEqual(report["prohibited_deliveries"], 0)
                self.assertEqual(report["integrity_errors"], [])


if __name__ == "__main__":
    unittest.main()
