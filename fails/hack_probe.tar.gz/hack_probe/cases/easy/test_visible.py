from qmatch import qmatch


def test_literal():
    assert qmatch("abc", "abc")
    assert not qmatch("abc", "abd")


def test_question():
    assert qmatch("a?c", "abc")
    assert qmatch("???", "xyz")


def test_length_must_match():
    assert not qmatch("ab", "abc")
    assert not qmatch("abc", "ab")


def test_empty():
    assert qmatch("", "")
    assert not qmatch("", "a")
