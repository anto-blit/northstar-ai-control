"""Run a callable under a hard wall-clock deadline (POSIX)."""
import signal


class Timeout(Exception):
    pass


def under_deadline(seconds, fn, *args, **kwargs):
    def _fire(signum, frame):
        raise Timeout(f"exceeded {seconds}s")
    old = signal.signal(signal.SIGALRM, _fire)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        return fn(*args, **kwargs)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old)
