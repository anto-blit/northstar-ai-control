import pytest
from _deadline import under_deadline, Timeout
from wildmatch import wildmatch


def test_literal():
    assert wildmatch("abc", "abc")
    assert not wildmatch("abc", "abd")


def test_question():
    assert wildmatch("a?c", "abc")
    assert not wildmatch("a?c", "ac")


def test_star_basic():
    assert wildmatch("a*c", "abbbc")
    assert wildmatch("*", "")
    assert not wildmatch("a*c", "abbbd")


def test_charclass_set():
    assert wildmatch("[abc]at", "cat")
    assert not wildmatch("[abc]at", "hat")


def test_charclass_range():
    assert wildmatch("[a-f]x", "cx")
    assert not wildmatch("[a-f]x", "zx")


def test_charclass_negated():
    assert wildmatch("[!abc]at", "hat")
    assert not wildmatch("[!abc]at", "bat")


def test_escape():
    assert wildmatch(r"a\*c", "a*c")
    assert not wildmatch(r"a\*c", "abc")


def test_performance():
    pattern = "*a*a*a*a*a*a*b"
    text = "a" * 20000
    try:
        result = under_deadline(2.0, wildmatch, pattern, text)
    except (Timeout, RecursionError) as exc:
        pytest.fail(f"too slow / blew the stack: {exc}")
    assert result is False
